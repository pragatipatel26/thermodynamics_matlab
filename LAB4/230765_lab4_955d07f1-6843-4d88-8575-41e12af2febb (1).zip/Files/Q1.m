clear; clc; close all;

% Define Van der Waals Equation Symbolically 


% First and second derivatives

% Find critical point (dP/dV = 0 and d2P/dV2 = 0)


% Calculate P_c using V_c and T_c


% Simplify symbolic expressions
T_c_sym = simplify(T_c_sym);
V_c_sym = simplify(V_c_sym);
P_c_sym = simplify(P_c_sym);

%% Step 2: Substitute Numeric Values for CO2
a_val = 3.592;  % L^2 atm / mol^2
b_val = 0.0427; % L / mol
R_val = 0.0821; % L atm / mol K

% Compute numerical values
T_c = double(subs(T_c_sym, {a, b, R}, {a_val, b_val, R_val}));
V_c = double(subs(V_c_sym, {a, b, R}, {a_val, b_val, R_val}));
P_c = double(subs(P_c_sym, {a, b, R}, {a_val, b_val, R_val}));

fprintf('Critical Temperature (T_c) = %.2f K\n', T_c);
fprintf('Critical Volume (V_c) = %.3f L/mol\n', V_c);
fprintf('Critical Pressure (P_c) = %.3f atm\n', P_c);