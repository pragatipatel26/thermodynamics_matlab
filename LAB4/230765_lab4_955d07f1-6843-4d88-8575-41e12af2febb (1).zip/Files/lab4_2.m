clc
clear all
close all
% define symbols
syms P V T R a b
%Define Van der Waals Equation Symbolically
P=(R*T)/(V-b)-a/V^2;

% calc. first derivative of P with respect to V (use diff() here)
dP_dV = diff(P,V);

% set dP/dV = 0 and find V as a function of T, a, b, and R symbolically. (use solve() here)
V_extrema_sym=solve(dP_dV==0,V);
% simplify expression
V_extrema_sym=simplify(V_extrema_sym);

%% a and b values
a_val = 3.592;  % L^2 atm / mol^2
b_val = 0.0427; % L / mol
R_val = 0.0821; % L atm / mol K

% critical temperature from prev. calc.
T_c = 303.59 ;%K

% set temp linspace range from T = 260 to T_c
T_values = linspace(260,T_c,10)

% generate a linear space in V and specify range (from 0.05 to 0.4, and
% generate 1000 points
V_values = linspace(0.05,0.4,1000);


% Create figure
figure; 
hold on; 
grid on;

for i=1:length(T_values)
    % calc. pressure values for this temperature (T_values(i)) and V_values. 
    
    % P_values array will be of the same size as V_values.
   
    % Use sub() for substitution and double() to return numerical values
    P_values=double(subs(P, {a, b, R,T,V}, {a_val, b_val, R_val,T_values(i),V_values}));
    % calc. extrema vol. (you will get 2 extrema Vs for each isotherm)
    V_extrema = double(subs(V_extrema_sym,{a, b, R,T}, {a_val, b_val, R_val,T_values(i)}));
    % calc. pressure at vol. extrema (you will again get 2 extrema Ps for
    % each isotherm)
    P_extrema =double(subs(P, {a, b, R,T,V}, {a_val, b_val, R_val,T_values(i),V_extrema}));
 
   % Plot isotherm
   plot(V_values,P_values);
   scatter(V_extrema,P_extrema,'r','filled','HandleVisibility','off');
   ylim([0,200]);
  

end
title('P-V isotherms');
xlabel('Volume');
ylabel('Pressure');
legend('T=260.0000' , 'T=264.8433' , 'T=269.6867' , 'T=274.5300',  'T=279.3733',  'T=284.2167',  'T=289.0600',  'T=293.9033 ', 'T=298.7467' , 'T=303.5900');