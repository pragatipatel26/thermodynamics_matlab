clear; clc; close all;

%% Setting up symbolic expressions

% define symbols


% Define Van der Waals Equation Symbolically


% calc. first derivative of P with respect to V (use diff() here)
dP_dV = 

% set dP/dV = 0 and find V as a function of T, a, b, and R symbolically. (use solve() here)
V_extrema_sym = 

% simplify expression


%% a and b values
a_val = 3.592;  % L^2 atm / mol^2
b_val = 0.0427; % L / mol
R_val = 0.0821; % L atm / mol K

% critical temperature from prev. calc.
T_c = 

% set temp linspace range from T = 260 to T_c
T_values = 

% generate a linear space in V and specify range (from 0.05 to 0.4, and
% generate 1000 points
V_values =  

% Create figure
figure; hold on; grid on;

% start a for loop here over T_values

    % calc. pressure values for this temperature (T_values(i)) and V_values. 
    % P_values array will be of the same size as V_values.
    % Use sub() for substitution and double() to return numerical values
    P_values =

    % calc. extrema vol. (you will get 2 extrema Vs for each isotherm)
    V_extrema = 

    % calc. pressure at vol. extrema (you will again get 2 extrema Ps for
    % each isotherm)
    P_extrema =


    % Plot isotherm


    % Plot max and min points in red

% end for loop


% format plot (font size and labels)
% NOTE use  to get a nice looking plot