clc
clear all
close all
% Define Van der Waals Equation Symbolically 
syms P V T R a b
P=(R*T)/(V-b)-a/V^2;
% First and second derivatives
dP_dV=diff(P,V);
d2P_dV2=diff(dP_dV,V);
% Find critical point (dP/dV = 0 and d2P/dV2 = 0)
[V_c_sym,T_c_sym]=solve(dP_dV==0,d2P_dV2==0,[V,T]);

% Calculate P_c using V_c and T_c
P_c_sym=subs(P,{V,T},{V_c_sym,T_c_sym});

% Simplify symbolic expressions
T_c_sym = simplify(T_c_sym);
V_c_sym = simplify(V_c_sym);
P_c_sym = simplify(P_c_sym);

%% Step 2: Substitute Numeric Values for CO2
a_val = 3.592;  % L^2 atm / mol^2
b_val = 0.0427; % L / mol
R_val = 0.0821; % L atm / mol K

% Compute numerical values
T_c = double(subs(T_c_sym, {a, b, R}, {a_val, b_val, R_val}));
V_c = double(subs(V_c_sym, {a, b, R}, {a_val, b_val, R_val}));
P_c = double(subs(P_c_sym, {a, b, R}, {a_val, b_val, R_val}));

fprintf('Critical Temperature (T_c) = %.2f K\n', T_c);
fprintf('Critical Volume (V_c) = %.3f L/mol\n', V_c);
fprintf('Critical Pressure (P_c) = %.3f atm\n', P_c);